public class MissadeFalecimento extends Missaespecial{

	
	

}
