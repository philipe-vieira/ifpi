
public class testa {

	public static void main(String[] args) {
		// TODO Auto-generated method stubge
		/*String duraçao;
		duraçao = (String) JOptionPane.showInputDialog(null, "escolha a duraçao do evento", "Duraçao do Evento.",
			        JOptionPane.QUESTION_MESSAGE, null, new Object[] { "30min","1h","1h30min","2h" }
		 , "2h");
		
		System.out.println(duraçao);
		louvor louvo = new louvor();
		louvo.inserirlouvor();
		System.out.println(louvo.reperprincipal);
		JOptionPane.showMessageDialog(null, louvo.calcularpreço());
		
		eventos even = new eventos();
		even.inserirevento();
		even.calcularpreço();*/
		
		contrato contar = new contrato();
		contar.contratar();

	}

}