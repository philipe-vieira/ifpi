public abstract class missa {
	String EntradaSacer, ato,  salmo, aclamacao, Ofertorio, Santo, Comunhao, Final;
	String HinoDeLouvor, AbracoDaPaz,  PosComunhao;
	double preco;
	
	abstract String imprimirLista();
	abstract void inserir();

}