/**
 * 
 */

/**
 * @author philipe
 *
 */
public interface calcular {
	
	double calcularpreço();
}
